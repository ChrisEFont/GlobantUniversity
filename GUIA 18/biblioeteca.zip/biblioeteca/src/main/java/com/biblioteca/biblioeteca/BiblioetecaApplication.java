package com.biblioteca.biblioeteca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BiblioetecaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BiblioetecaApplication.class, args);
	}

}
