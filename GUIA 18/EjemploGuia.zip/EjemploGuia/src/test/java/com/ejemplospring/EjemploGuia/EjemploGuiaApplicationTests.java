package com.ejemplospring.EjemploGuia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemploGuiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
